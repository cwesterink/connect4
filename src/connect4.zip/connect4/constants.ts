const NUM_COLUMNS = 7;
const NUM_ROWS = 6;

export { NUM_COLUMNS, NUM_ROWS };
